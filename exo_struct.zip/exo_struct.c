#pragma hdrstop
#pragma argsused

#include <stdio.h>

#ifdef _WIN32
#include <tchar.h>
#else
  typedef char _TCHAR;
  #define _tmain main
#endif


typedef struct
{   // Structure du Programme !
	char nom[20];
	char prenom [20];
	char classe [10];
	char adresse [50];
}student;

void menu(student * tab, int nbStudent, FILE * f);// Prototype de la fonction menu
void addStudent(student * tab, int nbStudent, FILE * f); // Prototype de la fonction pour ajouter un eleve
void displayStudent(student * tab, int nbStudent, FILE * f);  // Prototype de la fonction pour afficher les donn�es eleves
void saveStudent(student * tab, int nbStudent, FILE * f); // Prototype de la fonction pour stocker les donn�es eleves dans un fichier
void loadStudent(student * tab, int nbStudent, FILE * f);  // Prototype de la fonction pour lire les donn�es eleves dans un fichier

void menu(student * tab, int nbStudent, FILE * f)
{   // Menu du Programme Ecole
    int choix;
    printf("Bienvenue sur le programme de gestion d'eleves\n\n");
	printf("1-- Ajouter un eleve\n\n");
	printf("2-- Afficher les informations eleves\n\n");
	printf("3-- Sauvegarder les eleves dans un fichier\n\n");
	printf("4-- Charger les infos du fichier\n\n");
	printf("5-- Quitter : ");
	scanf("%d", &choix);

	switch(choix)
	{
		case 1:
			addStudent(tab, nbStudent, f);
			break;
		case 2:
			displayStudent(tab, nbStudent, f);
			break;
		case 3:
			saveStudent(tab, nbStudent, f);
			break;
		case 4:
			loadStudent(tab, nbStudent, f);
			break;
		case 5:
			break;
		default:
		break;
	}

}


void addStudent(student * tab, int nbStudent, FILE * f)
{   // Fonction qui permet d'ajouter un eleve dans l'�cole
	printf("Entrez le nom de l'eleve :\n");
	scanf("%s", tab[nbStudent].nom);
	printf("Entrez le prenom de l'eleve :\n");
	scanf("%s", tab[nbStudent].prenom);
	printf("Entrez la classe de l'eleve :\n");
	scanf("%s", tab[nbStudent].classe);
	printf("Entrez l'adresse de l'eleve :\n");
	scanf("%s", tab[nbStudent].adresse);

	printf("\nnom : %s \nprenom : %s \nclasse : %s \nadresse : %s", tab[nbStudent].nom, tab[nbStudent].prenom, tab[nbStudent].classe, tab[nbStudent].adresse);
	nbStudent++;
	menu(tab, nbStudent, f);
}



void displayStudent(student * tab, int nbStudent, FILE * f)
{	// Fonction qui permet d'afficher les donn�es de l'eleve
	int i;
	for ((i = 0); i < nbStudent; i++)
	{
		printf("\n Informations de l'eleve n : %d", i);
		printf("\nnom : %s \nprenom : %s \nclasse : %s \nadresse : %s", tab[i].nom, tab[i].prenom, tab[i].classe, tab[i].adresse);
	}
}

void saveStudent(student * tab, int nbStudent, FILE * f)
{	//Fonction qui permet de stocker les informations de l'�l�ve dans une fichier texte
	char texte[100];
	int i;
	int * nbS1;
	nbS1 = &nbStudent;
	f = fopen(texte, "r+");

    if (f == NULL)
	{
		fprintf(stderr,"\nOuverture du fichier impossible !");
	}
	fwrite(nbS1, sizeof(int), 1, f);
    fwrite(nbS1, sizeof(int), 1, f);
	fclose(f);
	menu(tab, nbStudent, f);

}
void loadStudent(student * tab, int nbStudent, FILE * f)
{  //Fonction qui permet de lire les informations de l'�l�ve dans une fichier texte
    char texte[100];
	int i;
	int * nbS1;
	nbS1 = &nbStudent;
	f = fopen(texte,"r+");
	
    if (f == NULL)
	{
		fprintf(stderr,"\nImpossible de lire dans le fichier !");
	}
	fread(nbS1, sizeof(int), 1, f);
    fread(tab, sizeof(int), 1, f);
	fclose(f);
	menu(tab, nbStudent, f);
}



int _tmain(int argc, _TCHAR* argv[]) 
{
    FILE * fichier;
    menu(tab, nbStudent, f);
	student tab[100];
	int nbStudent = 0;


    system("PAUSE");
	return 0;
}
